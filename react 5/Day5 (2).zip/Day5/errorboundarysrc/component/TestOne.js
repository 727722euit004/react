import React,{ Component } from "react";

export default class TestOne extends Component {
    render() {
        
        return(
           <div>
            <h1>Component One</h1>
           </div>
        );
    }
}