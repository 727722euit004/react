import React,{ Component } from "react";

export default class TestThree extends Component {
    render() {
        
        return(
           <div>
            <h1>Component Three</h1>
           </div>
        );
    }
}