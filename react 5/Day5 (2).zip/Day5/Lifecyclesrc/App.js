import './App.css';
import Lifecycle from './components/Lifecycle';

function App() {
  return (
    <div className="App">
      <Lifecycle />
    </div>
  );
}

export default App;
